﻿# ==========================================
# PERSONAGENS
# ==========================================

define caio = Character("Caio", color="#7F00FF")
define H20 = Character("H20", color="#7F00FF")
define radio = Character("Rádio", color="#FF0000")


# ==========================================
# IMAGENS
# ==========================================

image banheiro = "denovo.png"
image personagem = "H20 padrao.png"
image pato = "radio levantado.png"
image monstro = "Monster.png"
image banheiro = "denovo.png"
image H20 padrao = "H20 padrao.png"
image H20 confusa = "H20 confusa.png"
image H20 aterrorizada = "H20 aterrorizada.png"
image H20 gritandoalo = "H20 gritandoalo.png"
image H20 observando = "H20 observando.png"
image H20 palida = "H20 palida.png"
image H20 raiva = "H20 raiva.png"
image radio levantado = "radio levantado.png"
image radio indiferente = "radio indiferente.png"
image radio deprimido = "radio deprimido.png"
image radio agitado = "radio agitado.png"
image quartoescritorio = "quartoescritorio.png"
image encontrocorpo = "encontrocorpo.png"

# ==========================================
# TRANSFORMAÇÃO DO FUNDO
# ==========================================

transform fundo_grande:
    zoom 2.0
    xalign 0.5
    yalign 0.5


# ==========================================
# VARIÁVEIS DA BATALHA
# ==========================================

default H20_hp = 8
default monstro_hp = 4
default estilo_batalha = ""
default nivel_solitude = 0
default modo = ""


# ==========================================
# HUD DA BATALHA
# ==========================================

screen batalha_hud():

    frame:
        xalign 0.05
        yalign 0.05

        vbox:
            spacing 5

            text "H20"
            text "HP: [H20_hp] / 8"


    frame:
        xalign 0.95
        yalign 0.05

        vbox:
            spacing 5

            text "MONSTRO"
            text "HP: [monstro_hp] / 4"


# ==========================================
# INVESTIGAÇÃO DO BANHEIRO
# ==========================================

screen banheiro_investigacao():

    textbutton "TERMINAR INVESTIGAÇÃO":
        xalign 0.95
        yalign 0.05
        action Return()


    # ESPELHO
    textbutton " ":
        xpos 0.02
        ypos 0.25
        xsize 0.25
        ysize 0.55

        background None
        hover_background None

        action Show("descricao_espelho")


    # BANHEIRA
    textbutton " ":
        xpos 0.30
        ypos 0.45
        xsize 0.40
        ysize 0.35

        background None
        hover_background None

        action Show("descricao_banheira")


    # JANELA
    textbutton " ":
        xpos 0.72
        ypos 0.20
        xsize 0.25
        ysize 0.50

        background None
        hover_background None

        action Show("descricao_janela")


screen descricao_espelho():

    frame:
        xalign 0.5
        yalign 0.78

        vbox:
            spacing 15

            text "Um espelho velho e sujo."

            textbutton "FECHAR":
                action Hide("descricao_espelho")


screen descricao_banheira():

    frame:
        xalign 0.5
        yalign 0.78

        vbox:
            spacing 15

            text "Uma banheira vazia."

            textbutton "FECHAR":
                action Hide("descricao_banheira")


screen descricao_janela():

    frame:
        xalign 0.5
        yalign 0.78

        vbox:
            spacing 15

            text "A janela mostra um corredor escuro."

            textbutton "FECHAR":
                action Hide("descricao_janela")


# ==========================================
# INÍCIO
# ==========================================

label start:

    scene tafrio

    caio "Tá frio..."
    caio "Tá frio aqui dentro..."

    scene olhofechado
    with pixellate

    scene olhoabrindo
    with pixellate

    scene quartoescritorio
    with pixellate

    show H20 confusa at right

    H20 "Huh..."
    H20 "Que lugar é esse?"

    show H20 observando at right

    H20 "Como raios eu vim parar aqui?"

    show H20 gritandoalo at right

    H20 "Alô? Tem alguém aí?"

    show H20 observando at left
    with move

    scene encontrocorpo
    with pixellate

    H20 "O quê-?!"

    scene quartoescritorio
    with pixellate

    show H20 aterrorizada at left with pixellate

    show radio levantado at right
    with pixellate

    radio "E agora, no programa: Onde você está!"

    radio "Uma boa pergunta, minha cara, mas temo que tenha uma melhor:"

    radio "Quem é você?"

    jump quem_e_voce


# ==========================================
# QUEM É VOCÊ?
# ==========================================

label quem_e_voce:

    show H20 quemevoce at left
    with pixellate

    radio "{i}Quem é você?{/i}"

    menu:

        "Eu sou eu! É tudo que você precisa saber!":

            show H20 raiva at left
            with pixellate

            $ modo = "agressivo"

            show radio agitado at right
            with pixellate

            radio "Agressividade! Então estamos agressivos!"

            show radio deprimido at right
            with pixellate

            radio "Mas não vou me rebaixar a tal nível... é deselegante."

            show radio indiferente at right
            with pixellate

            radio "Olhe o seu pulso, talvez encontre algo (ou não, tanto faz...)."


        "(Olha para um livro na escrivaninha) ... Katnipess?":

            show H20 confusa at left
            with pixellate

            $ modo = "atrapalhado"

            radio "Oras, não seja boba! Não estamos em jogos felinos!"

            radio "(Era esse o nome? Acho que tinha algo a ver com voraz... nah.)"

            radio "Mas, já que gosta de jogos, vou te dar uma dica:"

            radio "Às vezes, a resposta está na palma da mão! (Ou no pulso...)"


        "Eu... quem sou eu?":

            show H20 palida at left
            with pixellate

            $ modo = "frio"

            radio "E lá vamos nós para mais uma crise de identidade..."

            show radio agitado at right
            with pixellate

            radio "A resposta tá na sua cara, cara!"

            radio "Ou melhor, no {u}pulso{/u}..."

            show radio deprimido at right
            with pixellate

            radio "Sacou? (Diz que sim, vai, eu odeio repetir coisas...)"

    jump ir_banheiro


# ==========================================
# BANHEIRO
# ==========================================

label ir_banheiro:

    scene banheiro

    show banheiro at fundo_grande

    show personagem:
        zoom 1.5
        xalign 0.2
        yalign 0.65

    H20 "Uau... um banheiro."

    show pato:
        zoom 1.2
        xalign 0.8
        yalign 0.65

    radio "O SUPREMO BANHEIRO???"

    H20 "Argh-? Uma hora você estoura os meus tímpanos."

    hide personagem
    hide pato

    "H20 e rádio começam a investigar o banheiro."

    call screen banheiro_investigacao


    # PERSONAGENS VOLTAM

    show personagem:
        zoom 1.5
        xalign 0.2
        yalign 0.65

    show pato:
        zoom 1.2
        xalign 0.8
        yalign 0.65

    H20 "Ah, esse banheiro tem bastante coisa, né?"

    radio "É."

    jump encontrar_monstro


# ==========================================
# ENCONTRO COM O MONSTRO
# ==========================================

label encontrar_monstro:

    hide personagem
    hide pato

    scene black

    "H20 e rádio saem do banheiro."

    pause 1.0

    "Eles caminham por um corredor mal iluminado."

    pause 1.0

    "De repente..."

    pause 0.5

    "Uma criatura aparece na frente deles."

    show monstro:
        xalign 0.5
        yalign 0.5

    H20 "..."

    radio "..."

    H20 "Que coisa é essa?"

    radio "Parece que ela não está muito feliz em ver a gente."

    pause 0.5

    jump iniciar_batalha


# ==========================================
# INÍCIO DA BATALHA
# ==========================================

label iniciar_batalha:

    $ H20_hp = 8
    $ monstro_hp = 4
    $ estilo_batalha = ""
    $ nivel_solitude = 0

    show screen batalha_hud

    "Uma batalha começou!"

    radio "Você só pode escolher APENAS UMA opção."

    menu:

        "Como H20 vai enfrentar o monstro?"

        "SOLITUDE":

            $ estilo_batalha = "solitude"

            jump escolher_rota_solitude


        "FUGA":

            $ estilo_batalha = "fuga"

            jump turno_jogador


        "CULPA":

            $ estilo_batalha = "culpa"

            jump turno_jogador


# ==========================================
# ROTAS DE SOLITUDE
# ==========================================

label escolher_rota_solitude:

    radio "Você escolheu SOLITUDE."

    radio "Agora você precisa escolher uma rota."

    menu:

        "Como H20 vai lidar com o monstro?"

        "Rota pacifista":

            $ nivel_solitude = 0


        "Ofensas leves":

            $ nivel_solitude = 1


        "Ofensas pesadas":

            $ nivel_solitude = 2

    jump turno_jogador


# ==========================================
# CONTROLE DA BATALHA
# ==========================================

label turno_jogador:

    if H20_hp <= 0:

        jump derrota


    # MONSTRO SÓ PODE SER DERROTADO PELA CULPA

    if estilo_batalha == "culpa" and monstro_hp <= 0:

        jump vitoria


    if estilo_batalha == "solitude":

        jump solitude


    elif estilo_batalha == "fuga":

        jump fuga


    elif estilo_batalha == "culpa":

        jump culpa


# ==========================================
# SOLITUDE
# ==========================================

label solitude:

    # -----------------------------
    # ROTA PACIFISTA
    # -----------------------------

    if nivel_solitude == 0:

        "H20 tenta conversar com o monstro."

        menu:

            "O que H20 vai dizer?"

            "Eu não quero lutar. Podemos conversar?":

                jump pacifista_2

            "Você parece assustado. Está tudo bem?":

                jump pacifista_2

            "Você não precisa lutar contra a gente.":

                jump pacifista_2


    # -----------------------------
    # OFENSAS LEVES
    # -----------------------------

    elif nivel_solitude == 1:

        "H20 decide provocar o monstro."

        "Ele ainda não está completamente furioso."

        menu:

            "O que H20 vai dizer?"

            "Você é meio estranho, sabia?":

                jump ofensa_leve_1

            "Você realmente acha que consegue me assustar?":

                jump ofensa_leve_1

            "Já vi monstros mais assustadores.":

                jump ofensa_leve_1


    # -----------------------------
    # OFENSAS PESADAS
    # -----------------------------

    elif nivel_solitude == 2:

        "H20 decide partir para ofensas mais pesadas."

        "O monstro fica extremamente irritado."

        menu:

            "O que H20 vai dizer?"

            "Você é patético.":

                jump ofensa_pesada_1

            "Você não passa de um fracassado.":

                jump ofensa_pesada_1

            "Eu não tenho medo de uma criatura como você.":

                jump ofensa_pesada_1


# ==========================================
# ROTA PACIFISTA
# ==========================================

label pacifista_2:

    "O monstro parece estar ouvindo H20."

    menu:

        "H20 continua:"

        "Eu só quero encontrar uma maneira de resolver isso.":

            jump pacifista_3

        "Você não precisa ficar com raiva.":

            jump pacifista_3

        "Talvez a gente possa simplesmente conversar.":

            jump pacifista_3


label pacifista_3:

    "O monstro começa a baixar a guarda."

    menu:

        "H20 tenta mais uma vez."

        "A gente pode simplesmente ir embora. Ninguém precisa se machucar.":

            jump solitude_final

        "Você parece estar cansado dessa luta.":

            jump solitude_final

        "Não precisamos continuar brigando.":

            jump solitude_final


label solitude_final:

    "O monstro fica em silêncio."

    pause 1.0

    "Ele olha para H20."

    pause 1.0

    "Depois olha para o rádio."

    pause 1.0

    "O monstro finalmente abaixa os braços."

    "Ele desistiu da batalha."

    H20 "Então... acabou?"

    radio "Parece que sim."

    jump depois_da_batalha


# ==========================================
# OFENSAS LEVES
# ==========================================

label ofensa_leve_1:

    "O monstro fica irritado."

    "Ele ataca H20!"

    $ joel_hp -= 1

    "H20 perdeu 1 HP."

    jump ofensa_leve_2


label ofensa_leve_2:

    if H20_hp <= 0:

        jump derrota

    "O monstro encara H20."

    "Ele está ficando cada vez mais irritado."

    menu:

        "H20 continua provocando:"

        "Você faz essa cara para assustar quem?":

            jump ofensa_leve_3

        "Nossa, você fica ainda mais feio quando está bravo.":

            jump ofensa_leve_3

        "Era só isso que você tinha para mostrar?":

            jump ofensa_leve_3


label ofensa_leve_3:

    "O monstro rosna."

    "Ele ataca H20 novamente."

    $ H20_hp -= 1

    "H20 perdeu 1 HP."

    if H20_hp <= 0:

        jump derrota

    "O monstro parece cansado."

    "Depois de tanta provocação, ele finalmente recua."

    "A batalha termina."

    jump depois_da_batalha


# ==========================================
# OFENSAS PESADAS
# ==========================================

label ofensa_pesada_1:

    "O monstro fica completamente furioso."

    "Ele parte para cima de H20!"

    $ H20_hp -= 2

    "H20 perdeu 2 HP."

    jump ofensa_pesada_2


label ofensa_pesada_2:

    if H20_hp <= 0:

        jump derrota

    "O monstro está tomado pela raiva."

    menu:

        "H20 continua provocando:"

        "Você é ainda mais fraco do que parece.":

            jump ofensa_pesada_3

        "Vai fazer alguma coisa ou só ficar rosnando?":

            jump ofensa_pesada_3

        "Eu esperava muito mais de você.":

            jump ofensa_pesada_3


# ==========================================
# AQUI O MONSTRO NÃO RECUA
# ==========================================

label ofensa_pesada_3:

    "O monstro perde completamente a paciência."

    "Ele ataca com toda a força!"

    $ H20_hp -= 2

    "H20 perdeu 2 HP."

    if H20_hp <= 0:

        jump derrota

    "O monstro continua encarando H20."

    "Ele ainda está furioso."

    "Ele não vai recuar."

    jump turno_jogador


# ==========================================
# FUGA
# ==========================================

label fuga:

    "H20 tenta fugir!"

    $ chance_fuga = renpy.random.randint(1, 100)


    if chance_fuga <= 60:

        "H20 conseguiu fugir!"

        hide screen batalha_hud
        hide monstro

        jump depois_da_batalha


    else:

        "H20 não conseguiu fugir!"

        "O monstro alcança H20."

        $ H20_hp -= 1

        "H20 perdeu 1 HP."

        jump turno_jogador


# ==========================================
# CULPA
# ==========================================

label culpa:

    "H20 tenta atacar o monstro!"

    $ chance_ataque = renpy.random.randint(1, 100)


    if chance_ataque <= 50:

        "ACERTOU!"

        $ monstro_hp -= 1

        "O monstro perdeu 1 HP."


    else:

        "ERROU!"

        "O monstro contra-ataca."

        $ H20_hp -= 1

        "H20 perdeu 1 HP."


    jump turno_jogador


# ==========================================
# VITÓRIA
# ==========================================

label vitoria:

    hide screen batalha_hud
    hide monstro

    scene black

    "O monstro foi derrotado."

    pause 0.5

    H20 "Conseguimos..."

    radio "Finalmente."

    jump depois_da_batalha


# ==========================================
# DERROTA
# ==========================================

label derrota:

    hide screen batalha_hud
    hide monstro

    scene black

    "H20 caiu no chão."

    pause 1.0

    "GAME OVER."

    return


# ==========================================
# DEPOIS DA BATALHA
# ==========================================

label depois_da_batalha:

    hide screen batalha_hud

    scene black

    show personagem:
        zoom 1.5
        xalign 0.2
        yalign 0.65

    show pato:
        zoom 1.2
        xalign 0.8
        yalign 0.65

    H20 "Acho que acabou."

    radio "Por enquanto..."

    return